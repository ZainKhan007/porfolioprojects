--
-- Database: `oneclickreg`
--

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `course_code` varchar(100) NOT NULL,
  `course_name` varchar(100) NOT NULL,
  `course_rate` double NOT NULL,
  `credit_hours` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`course_code`, `course_name`, `course_rate`, `credit_hours`) VALUES
('CSC-320', 'Operating System', 6000, 3),
('CSE-321', 'Networking', 6000, 3),
('GSC-122', 'Probability', 5000, 3),
('PSE-321', 'Programming', 6000, 3),
('SEN-311', 'Software Construction', 6000, 3),
('SEN-320', 'HCI', 6000, 3),
('SEN-323', 'Formal Methods', 6000, 3);

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `reg_id` int(11) NOT NULL,
  `std_enrollment` varchar(255) NOT NULL,
  `reg_date` date NOT NULL,
  `total_hours` int(11) NOT NULL,
  `std_semester` varchar(255) NOT NULL,
  `program` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`reg_id`, `std_enrollment`, `reg_date`, `total_hours`, `std_semester`, `program`, `status`) VALUES
(91, '02131152087', '2018-03-16', 12, '2', 'bse', 'Registered');

-- --------------------------------------------------------

--
-- Table structure for table `reg_details`
--

CREATE TABLE `reg_details` (
  `d_id` int(11) NOT NULL,
  `reg_id` int(11) NOT NULL,
  `couse_code` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reg_details`
--

INSERT INTO `reg_details` (`d_id`, `reg_id`, `couse_code`) VALUES
(309, 91, 'CSE-321'),
(310, 91, 'SEN-311'),
(311, 91, 'GSC-122'),
(312, 91, 'SEN-323');

-- --------------------------------------------------------

--
-- Table structure for table `result_details`
--

CREATE TABLE `result_details` (
  `r_id` int(100) NOT NULL,
  `std_enrollment` varchar(100) NOT NULL,
  `program` varchar(50) NOT NULL,
  `status` varchar(20) NOT NULL,
  `semester` int(11) NOT NULL,
  `course_code` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `result_details`
--

INSERT INTO `result_details` (`r_id`, `std_enrollment`, `program`, `status`, `semester`, `course_code`) VALUES
(1, '02131152087', 'BSE', 'A', 1, 'PSE-321'),
(2, '02131152087', 'BSE', 'B', 1, 'SEN-320'),
(3, '02131152087', 'BSE', 'C', 1, 'CSC-320');

-- --------------------------------------------------------

--
-- Table structure for table `road_map`
--

CREATE TABLE `road_map` (
  `rm_id` int(11) NOT NULL,
  `couse_code` varchar(11) NOT NULL,
  `semester` int(11) NOT NULL,
  `program` varchar(50) NOT NULL,
  `pre_req_course_code` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `road_map`
--

INSERT INTO `road_map` (`rm_id`, `couse_code`, `semester`, `program`, `pre_req_course_code`) VALUES
(1, 'CSC-320', 1, 'BSE', ''),
(2, 'CSE-321', 2, 'BSE', 'CSC-320'),
(3, 'SEN-311', 2, 'BSE', 'PSE-321'),
(4, 'PSE-321', 1, 'BSE', ''),
(5, 'GSC-122', 2, 'BSE', ''),
(6, 'SEN-320', 1, 'BSE', ''),
(7, 'SEN-323', 2, 'BSE', '');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `std_enrollment` varchar(100) NOT NULL,
  `std_name` varchar(50) NOT NULL,
  `std_program` varchar(50) NOT NULL,
  `std_intake_sem` varchar(50) NOT NULL,
  `std_email` varchar(100) NOT NULL,
  `std_reg` varchar(50) NOT NULL,
  `std_father_name` varchar(50) NOT NULL,
  `std_degree_duration` int(11) NOT NULL,
  `std_max_sem` varchar(50) NOT NULL,
  `std_address` text NOT NULL,
  `std_mobile_no` int(11) NOT NULL,
  `type_id` int(11) NOT NULL,
  `password` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`std_enrollment`, `std_name`, `std_program`, `std_intake_sem`, `std_email`, `std_reg`, `std_father_name`, `std_degree_duration`, `std_max_sem`, `std_address`, `std_mobile_no`, `type_id`, `password`) VALUES
('02131152087', 'Zain', 'BSE', '2015', 'm.zainkhan1996@gmail.com', '40970', 'Abdul Sattar Khan', 4, '4', 'North Karachi', 8687, 1, 'zain123');

-- --------------------------------------------------------

--
-- Table structure for table `student_types`
--

CREATE TABLE `student_types` (
  `type_id` int(11) NOT NULL,
  `type_name` varchar(200) NOT NULL,
  `type_discount_per` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_types`
--

INSERT INTO `student_types` (`type_id`, `type_name`, `type_discount_per`) VALUES
(1, 'navy', 40),
(2, 'civilian', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`course_code`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`reg_id`),
  ADD KEY `std_reg` (`std_enrollment`);

--
-- Indexes for table `reg_details`
--
ALTER TABLE `reg_details`
  ADD PRIMARY KEY (`d_id`),
  ADD KEY `reg_det` (`reg_id`),
  ADD KEY `det_course` (`couse_code`);

--
-- Indexes for table `result_details`
--
ALTER TABLE `result_details`
  ADD PRIMARY KEY (`r_id`),
  ADD KEY `result_student` (`std_enrollment`),
  ADD KEY `foreign_key_course_code` (`course_code`);

--
-- Indexes for table `road_map`
--
ALTER TABLE `road_map`
  ADD PRIMARY KEY (`rm_id`),
  ADD KEY `couse_code` (`couse_code`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`std_enrollment`),
  ADD KEY `type_std` (`type_id`);

--
-- Indexes for table `student_types`
--
ALTER TABLE `student_types`
  ADD PRIMARY KEY (`type_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `registration`
--
ALTER TABLE `registration`
  MODIFY `reg_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=92;
--
-- AUTO_INCREMENT for table `reg_details`
--
ALTER TABLE `reg_details`
  MODIFY `d_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=313;
--
-- AUTO_INCREMENT for table `result_details`
--
ALTER TABLE `result_details`
  MODIFY `r_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `road_map`
--
ALTER TABLE `road_map`
  MODIFY `rm_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `student_types`
--
ALTER TABLE `student_types`
  MODIFY `type_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `registration`
--
ALTER TABLE `registration`
  ADD CONSTRAINT `std_reg` FOREIGN KEY (`std_enrollment`) REFERENCES `students` (`std_enrollment`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `reg_details`
--
ALTER TABLE `reg_details`
  ADD CONSTRAINT `det_course` FOREIGN KEY (`couse_code`) REFERENCES `courses` (`course_code`),
  ADD CONSTRAINT `foreign_key_reg` FOREIGN KEY (`reg_id`) REFERENCES `registration` (`reg_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `result_details`
--
ALTER TABLE `result_details`
  ADD CONSTRAINT `foreign_key_course_code` FOREIGN KEY (`course_code`) REFERENCES `courses` (`course_code`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `result_student` FOREIGN KEY (`std_enrollment`) REFERENCES `students` (`std_enrollment`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `road_map`
--
ALTER TABLE `road_map`
  ADD CONSTRAINT `road_map_ibfk_1` FOREIGN KEY (`couse_code`) REFERENCES `courses` (`course_code`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `students`
--
ALTER TABLE `students`
  ADD CONSTRAINT `type_std` FOREIGN KEY (`type_id`) REFERENCES `student_types` (`type_id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
